import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Query Client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      staleTime: 10000,
      refetchInterval: 15000,
    },
  },
});

// Types
interface WalletData {
  address: string;
  balance: number;
  transactions: Transaction[];
  tokens: Token[];
  transfers: Transfer[];
}

interface Transaction {
  signature: string;
  blockTime: number;
  status: 'success' | 'failed';
  fee: number;
  type: string;
}

interface Token {
  mint: string;
  symbol: string;
  name: string;
  balance: number;
  decimals: number;
  usdValue: number;
  logoUrl?: string;
}

interface Transfer {
  from: string;
  to: string;
  amount: number;
  signature: string;
  blockTime: number;
}

interface BubbleNode {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  isMain: boolean;
  balance: number;
  amount: number;
  isSource: boolean;
  color: string;
  fixed?: boolean;
}

// Validation
const isValidSolanaAddress = (address: string): boolean => {
  const base58Regex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
  return base58Regex.test(address);
};

// Génération de couleur déterministe
const generateColor = (seed: string): string => {
  const hash = seed.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const colors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
    '#F8B500', '#00CED1', '#FF6347', '#7B68EE', '#3CB371'
  ];
  return colors[hash % colors.length];
};

// API Service avec données simulées réalistes
const analyzeWallet = async (address: string): Promise<WalletData> => {
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const hash = address.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const rand = (seed: number) => {
    const x = Math.sin(seed) * 10000;
    return x - Math.floor(x);
  };
  
  const balance = rand(hash) * 500 + 10;
  const txCount = Math.floor(rand(hash + 1) * 50) + 10;
  const tokenCount = Math.floor(rand(hash + 2) * 8) + 2;
  const transferCount = Math.floor(rand(hash + 3) * 20) + 8;
  
  const tokenList = [
    { symbol: 'USDC', name: 'USD Coin', logo: '💵' },
    { symbol: 'USDT', name: 'Tether USD', logo: '💴' },
    { symbol: 'RAY', name: 'Raydium', logo: '☀️' },
    { symbol: 'BONK', name: 'Bonk', logo: '🐕' },
    { symbol: 'JTO', name: 'Jito', logo: '⚡' },
    { symbol: 'WIF', name: 'dogwifhat', logo: '🎩' },
    { symbol: 'ORCA', name: 'Orca', logo: '🐋' },
    { symbol: 'JUP', name: 'Jupiter', logo: '🪐' },
  ];
  
  const tokens: Token[] = Array.from({ length: tokenCount }, (_, i) => {
    const token = tokenList[Math.floor(rand(hash + i + 100) * tokenList.length)];
    const tokenBalance = rand(hash + i + 200) * 10000;
    const price = rand(hash + i + 300) * 5;
    return {
      mint: `${address.slice(0, 8)}...token${i}`,
      symbol: token.symbol,
      name: token.name,
      balance: tokenBalance,
      decimals: 6,
      usdValue: tokenBalance * price,
      logoUrl: token.logo,
    };
  });
  
  const transactions: Transaction[] = Array.from({ length: txCount }, (_, i) => ({
    signature: `${hash}${i}${'x'.repeat(80)}`.slice(0, 88),
    blockTime: Date.now() / 1000 - i * 3600 * rand(hash + i),
    status: rand(hash + i + 400) > 0.1 ? 'success' : 'failed',
    fee: 0.000005,
    type: ['Transfer', 'Swap', 'Stake', 'NFT'][Math.floor(rand(hash + i + 500) * 4)],
  }));
  
  const generateWalletAddress = (seed: number): string => {
    const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let addr = '';
    for (let i = 0; i < 44; i++) {
      addr += chars[Math.floor(rand(seed + i) * chars.length)];
    }
    return addr;
  };
  
  const connectedWallets = Array.from({ length: transferCount }, (_, i) => generateWalletAddress(hash + i * 1000));
  
  const transfers: Transfer[] = connectedWallets.map((wallet, i) => ({
    from: rand(hash + i + 600) > 0.5 ? address : wallet,
    to: rand(hash + i + 600) > 0.5 ? wallet : address,
    amount: rand(hash + i + 700) * 100,
    signature: `tx${hash}${i}`,
    blockTime: Date.now() / 1000 - i * 86400,
  }));
  
  return { address, balance, transactions, tokens, transfers };
};

// Format helpers
const formatAddress = (addr: string) => `${addr.slice(0, 6)}...${addr.slice(-4)}`;
const formatNumber = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Landing Page avec Bubble Map Preview
const LandingPage: React.FC<{ onSearch: (address: string) => void }> = ({ onSearch }) => {
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Animated background bubbles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);
    
    const bubbles: { x: number; y: number; r: number; vx: number; vy: number; color: string }[] = [];
    const colors = ['#9945FF', '#14F195', '#00D4AA', '#F97316', '#06B6D4'];
    
    for (let i = 0; i < 25; i++) {
      bubbles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: 20 + Math.random() * 60,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
    
    let animationId: number;
    const animate = () => {
      ctx.fillStyle = 'rgba(5, 6, 10, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Draw connections
      ctx.strokeStyle = 'rgba(153, 69, 255, 0.1)';
      ctx.lineWidth = 1;
      for (let i = 0; i < bubbles.length; i++) {
        for (let j = i + 1; j < bubbles.length; j++) {
          const dx = bubbles[j].x - bubbles[i].x;
          const dy = bubbles[j].y - bubbles[i].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 200) {
            ctx.beginPath();
            ctx.moveTo(bubbles[i].x, bubbles[i].y);
            ctx.lineTo(bubbles[j].x, bubbles[j].y);
            ctx.stroke();
          }
        }
      }
      
      // Draw and update bubbles
      for (const bubble of bubbles) {
        bubble.x += bubble.vx;
        bubble.y += bubble.vy;
        
        if (bubble.x < 0 || bubble.x > canvas.width) bubble.vx *= -1;
        if (bubble.y < 0 || bubble.y > canvas.height) bubble.vy *= -1;
        
        const gradient = ctx.createRadialGradient(bubble.x, bubble.y, 0, bubble.x, bubble.y, bubble.r);
        gradient.addColorStop(0, bubble.color + '40');
        gradient.addColorStop(1, 'transparent');
        
        ctx.beginPath();
        ctx.arc(bubble.x, bubble.y, bubble.r, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();
        
        ctx.beginPath();
        ctx.arc(bubble.x, bubble.y, bubble.r * 0.3, 0, Math.PI * 2);
        ctx.fillStyle = bubble.color + '60';
        ctx.fill();
      }
      
      animationId = requestAnimationFrame(animate);
    };
    animate();
    
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) {
      setError('Please enter an address');
      return;
    }
    if (!isValidSolanaAddress(trimmed)) {
      setError('Invalid Solana address format');
      return;
    }
    setError('');
    onSearch(trimmed);
  };

  const exampleAddresses = [
    { label: 'Example Wallet 1', address: 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4' },
    { label: 'Example Wallet 2', address: '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM' },
  ];

  return (
    <div className="min-h-screen bg-[#05060a] relative overflow-hidden flex items-center justify-center">
      {/* Animated Canvas Background */}
      <canvas ref={canvasRef} className="absolute inset-0" />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#05060a]/50 to-[#05060a]" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-5xl mx-auto px-6 text-center">
        {/* Logo */}
        <div className="inline-flex items-center justify-center mb-10">
          <div className="relative">
            <div className="w-28 h-28 rounded-3xl flex items-center justify-center animate-pulse"
              style={{
                background: 'linear-gradient(135deg, #9945FF 0%, #14F195 50%, #00D4AA 100%)',
                boxShadow: '0 0 80px rgba(153, 69, 255, 0.5), 0 0 160px rgba(20, 241, 149, 0.3)',
              }}
            >
              <svg viewBox="0 0 100 100" className="w-16 h-16">
                <path d="M20 65 L40 45 L80 45" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M20 50 L60 50 L80 30" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M20 35 L40 55 L80 55" stroke="white" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </div>

        {/* Title */}
        <h1 className="text-6xl md:text-8xl font-black mb-6 tracking-tight">
          <span className="bg-gradient-to-r from-white via-white to-gray-400 bg-clip-text text-transparent">
            Solana
          </span>
          <br />
          <span className="bg-gradient-to-r from-[#9945FF] via-[#14F195] to-[#00D4AA] bg-clip-text text-transparent">
            Explorer
          </span>
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-400 font-light max-w-3xl mx-auto mb-12 leading-relaxed">
          Professional wallet tracking with <span className="text-[#14F195] font-semibold">interactive bubble maps</span>.
          <br className="hidden md:block" />
          Visualize connections, track flows, analyze networks.
        </p>

        {/* Search Box */}
        <form onSubmit={handleSubmit} className="relative max-w-3xl mx-auto mb-8">
          <div className={`
            relative rounded-2xl transition-all duration-500
            ${isFocused 
              ? 'shadow-[0_0_0_3px_rgba(153,69,255,0.5),0_0_80px_rgba(153,69,255,0.4)]' 
              : 'shadow-[0_0_0_1px_rgba(255,255,255,0.1),0_0_40px_rgba(153,69,255,0.1)]'
            }
          `}>
            <div className="relative flex items-center bg-[#0d0e14]/90 backdrop-blur-xl rounded-2xl overflow-hidden">
              <div className="pl-6 pr-3">
                <svg className="w-7 h-7 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              
              <input
                type="text"
                value={input}
                onChange={(e) => { setInput(e.target.value); setError(''); }}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                placeholder="Enter Solana wallet address..."
                className="flex-1 bg-transparent py-6 px-3 text-xl text-white placeholder-gray-500 focus:outline-none font-mono"
                spellCheck={false}
              />
              
              <button
                type="button"
                onClick={async () => {
                  try {
                    const text = await navigator.clipboard.readText();
                    setInput(text);
                  } catch {}
                }}
                className="px-5 py-2.5 mr-3 text-sm font-medium text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-all border border-white/10"
              >
                Paste
              </button>
              
              <button
                type="submit"
                className="m-2 px-10 py-4 rounded-xl font-bold text-lg text-white transition-all duration-300 hover:scale-105 hover:shadow-[0_0_40px_rgba(153,69,255,0.5)]"
                style={{
                  background: 'linear-gradient(135deg, #9945FF 0%, #14F195 100%)',
                }}
              >
                Explore →
              </button>
            </div>
          </div>
          
          {error && (
            <div className="absolute -bottom-10 left-0 right-0 text-red-400 text-sm flex items-center justify-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}
        </form>

        {/* Example Addresses */}
        <div className="flex flex-wrap justify-center gap-4 mt-16">
          <span className="text-gray-500 text-sm self-center">Quick start:</span>
          {exampleAddresses.map((ex) => (
            <button
              key={ex.address}
              onClick={() => onSearch(ex.address)}
              className="group px-5 py-3 text-sm rounded-xl bg-white/5 hover:bg-gradient-to-r hover:from-[#9945FF]/20 hover:to-[#14F195]/20 text-gray-400 hover:text-white border border-white/10 hover:border-[#9945FF]/50 transition-all duration-300 font-mono"
            >
              <span className="group-hover:hidden">{ex.label}</span>
              <span className="hidden group-hover:inline">{formatAddress(ex.address)}</span>
            </button>
          ))}
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
          {[
            { icon: '🗺️', title: 'Interactive Bubble Maps', desc: 'Drag, zoom, and explore wallet networks visually', color: '#9945FF' },
            { icon: '🔗', title: 'Track Connections', desc: 'See all wallets connected through transfers', color: '#14F195' },
            { icon: '⚡', title: 'Real-time Analysis', desc: 'Live data from Solana blockchain', color: '#F97316' },
          ].map((feature) => (
            <div
              key={feature.title}
              className="group p-8 rounded-2xl bg-gradient-to-b from-white/[0.05] to-transparent border border-white/[0.08] hover:border-opacity-30 transition-all duration-300"
              style={{ '--hover-color': feature.color } as React.CSSProperties}
            >
              <div className="text-5xl mb-5 group-hover:scale-125 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-500">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Loading Screen
const LoadingScreen: React.FC<{ progress: number; status: string }> = ({ progress, status }) => (
  <div className="min-h-screen bg-[#05060a] flex items-center justify-center">
    <div className="text-center">
      <div className="relative w-40 h-40 mx-auto mb-10">
        <svg className="w-full h-full -rotate-90">
          <circle cx="80" cy="80" r="70" fill="none" stroke="#1a1b25" strokeWidth="8" />
          <circle 
            cx="80" cy="80" r="70" fill="none" 
            stroke="url(#progressGradient)" 
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={440}
            strokeDashoffset={440 - (440 * progress) / 100}
            className="transition-all duration-300"
          />
          <defs>
            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#9945FF" />
              <stop offset="100%" stopColor="#14F195" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-4xl font-bold bg-gradient-to-r from-[#9945FF] to-[#14F195] bg-clip-text text-transparent">
            {Math.round(progress)}%
          </span>
        </div>
      </div>
      <p className="text-gray-400 text-lg">{status}</p>
    </div>
  </div>
);

// Interactive Bubble Map
const BubbleMap: React.FC<{ 
  data: WalletData; 
  onBack: () => void; 
  onWalletClick: (addr: string) => void 
}> = ({ data, onBack, onWalletClick }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 1200, height: 800 });
  const [nodes, setNodes] = useState<BubbleNode[]>([]);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; node: BubbleNode; locked: boolean } | null>(null);
  const [hoveredLink, setHoveredLink] = useState<{ source: string; target: string; amount: number; x: number; y: number } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [showPanel, setShowPanel] = useState(true);
  const [highlightedNode, setHighlightedNode] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'transfers' | 'tokens'>('transfers');
  const dragRef = useRef<{ nodeId: string | null; startX: number; startY: number }>({ nodeId: null, startX: 0, startY: 0 });
  const panStartRef = useRef({ x: 0, y: 0 });
  const tooltipTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Process connected wallets
  const connectedWallets = useMemo(() => {
    const walletMap = new Map<string, { amount: number; isSource: boolean; txCount: number }>();
    data.transfers.forEach(t => {
      const other = t.from === data.address ? t.to : t.from;
      const isSource = t.from === data.address;
      const existing = walletMap.get(other);
      if (existing) {
        existing.amount += t.amount;
        existing.txCount += 1;
      } else {
        walletMap.set(other, { amount: t.amount, isSource, txCount: 1 });
      }
    });
    return Array.from(walletMap.entries())
      .map(([addr, info]) => ({ address: addr, ...info }))
      .sort((a, b) => b.amount - a.amount);
  }, [data]);

  const maxAmount = Math.max(...connectedWallets.map(w => w.amount), 1);

  // Initialize nodes
  useEffect(() => {
    const container = containerRef.current;
    if (container) {
      setDimensions({ width: container.clientWidth, height: container.clientHeight });
    }

    const centerX = dimensions.width / 2;
    const centerY = dimensions.height / 2;
    
    const mainNode: BubbleNode = {
      id: data.address,
      x: centerX,
      y: centerY,
      vx: 0,
      vy: 0,
      radius: 70,
      isMain: true,
      balance: data.balance,
      amount: 0,
      isSource: false,
      color: '#9945FF',
      fixed: true,
    };
    
    const otherNodes: BubbleNode[] = connectedWallets.slice(0, 25).map((wallet, i) => {
      const angle = (i / Math.min(connectedWallets.length, 25)) * Math.PI * 2 - Math.PI / 2;
      const distance = 280 + (i % 4) * 60;
      const sizeRatio = wallet.amount / maxAmount;
      const radius = 25 + sizeRatio * 40;
      
      return {
        id: wallet.address,
        x: centerX + Math.cos(angle) * distance,
        y: centerY + Math.sin(angle) * distance,
        vx: 0,
        vy: 0,
        radius,
        isMain: false,
        balance: wallet.amount * 0.8,
        amount: wallet.amount,
        isSource: wallet.isSource,
        color: generateColor(wallet.address),
        fixed: false,
      };
    });
    
    setNodes([mainNode, ...otherNodes]);
  }, [data, connectedWallets, maxAmount, dimensions]);

  // Resize handler
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        setDimensions({ 
          width: containerRef.current.clientWidth, 
          height: containerRef.current.clientHeight 
        });
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Links data
  const links = useMemo(() => {
    return connectedWallets.slice(0, 25).map(wallet => ({
      source: data.address,
      target: wallet.address,
      amount: wallet.amount,
      isSource: wallet.isSource,
    }));
  }, [data, connectedWallets]);

  const getNodeById = (id: string) => nodes.find(n => n.id === id);

  const getColor = (amount: number) => {
    const ratio = amount / maxAmount;
    if (ratio > 0.6) return '#ef4444';
    if (ratio > 0.3) return '#f97316';
    return '#22c55e';
  };

  // Mouse handlers for dragging nodes
  const handleMouseDown = (e: React.MouseEvent, nodeId: string) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    
    const node = getNodeById(nodeId);
    if (!node || node.isMain) return;
    
    dragRef.current = {
      nodeId,
      startX: e.clientX,
      startY: e.clientY,
    };
    
    setNodes(prev => prev.map(n => 
      n.id === nodeId ? { ...n, fixed: true } : n
    ));
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    // Handle node dragging
    if (dragRef.current.nodeId) {
      const dx = (e.clientX - dragRef.current.startX) / zoom;
      const dy = (e.clientY - dragRef.current.startY) / zoom;
      
      setNodes(prev => prev.map(n => {
        if (n.id === dragRef.current.nodeId) {
          return { ...n, x: n.x + dx, y: n.y + dy };
        }
        return n;
      }));
      
      dragRef.current.startX = e.clientX;
      dragRef.current.startY = e.clientY;
      return;
    }
    
    // Handle panning
    if (isPanning) {
      const dx = e.clientX - panStartRef.current.x;
      const dy = e.clientY - panStartRef.current.y;
      setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      panStartRef.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handleMouseUp = () => {
    if (dragRef.current.nodeId) {
      setNodes(prev => prev.map(n => 
        n.id === dragRef.current.nodeId ? { ...n, fixed: false } : n
      ));
      dragRef.current.nodeId = null;
    }
    setIsPanning(false);
  };

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0 && !dragRef.current.nodeId) {
      setIsPanning(true);
      panStartRef.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom(z => Math.max(0.2, Math.min(4, z * delta)));
  };

  // Tooltip handlers
  const handleNodeHover = (e: React.MouseEvent, node: BubbleNode) => {
    if (tooltip?.locked) return;
    if (tooltipTimeoutRef.current) clearTimeout(tooltipTimeoutRef.current);
    
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    setTooltip({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      node,
      locked: false,
    });
  };

  const handleNodeLeave = () => {
    if (tooltip?.locked) return;
    tooltipTimeoutRef.current = setTimeout(() => {
      setTooltip(null);
    }, 100);
  };

  const handleTooltipEnter = () => {
    if (tooltipTimeoutRef.current) clearTimeout(tooltipTimeoutRef.current);
    setTooltip(prev => prev ? { ...prev, locked: true } : null);
  };

  const handleTooltipLeave = () => {
    setTooltip(null);
  };

  // Link hover
  const handleLinkHover = (e: React.MouseEvent, link: typeof links[0]) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    setHoveredLink({
      source: link.source,
      target: link.target,
      amount: link.amount,
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  return (
    <div className="h-screen bg-[#05060a] flex flex-col overflow-hidden">
      {/* Header */}
      <header className="border-b border-white/5 bg-[#05060a]/90 backdrop-blur-xl px-6 py-3 flex items-center justify-between shrink-0 z-50">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2.5 rounded-xl hover:bg-white/5 text-gray-400 hover:text-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #9945FF, #14F195)' }}
            >
              <span className="text-white font-bold text-sm">{data.address.slice(0, 2)}</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-white font-medium">{formatAddress(data.address)}</span>
                <button
                  onClick={() => navigator.clipboard.writeText(data.address)}
                  className="p-1.5 rounded-lg hover:bg-white/10 text-gray-500 hover:text-white transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </button>
              </div>
              <div className="text-xs text-gray-500">{formatNumber(data.balance)} SOL</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 bg-[#0d0e14] rounded-xl p-1">
          <button
            onClick={() => setActiveTab('transfers')}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'transfers'
                ? 'bg-gradient-to-r from-[#9945FF] to-[#14F195] text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            🔗 Transfers
          </button>
          <button
            onClick={() => setActiveTab('tokens')}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'tokens'
                ? 'bg-gradient-to-r from-[#9945FF] to-[#14F195] text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            🪙 Tokens
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm bg-[#0d0e14] px-4 py-2 rounded-xl">
            <span className="text-gray-500">Zoom:</span>
            <span className="text-white font-mono font-medium">{(zoom * 100).toFixed(0)}%</span>
          </div>
          
          <a
            href={`https://solscan.io/account/${data.address}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-[#14F195]/10 text-[#14F195] hover:bg-[#14F195]/20 transition-colors text-sm font-medium"
          >
            View on Solscan ↗
          </a>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden relative">
        {/* Side Panel */}
        <div className={`
          absolute left-0 top-0 bottom-0 w-80 bg-[#0a0b10]/95 backdrop-blur-xl border-r border-white/5 z-20
          transition-transform duration-300 flex flex-col
          ${showPanel ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="p-4 border-b border-white/5">
            <h3 className="font-bold text-white text-lg">
              {activeTab === 'transfers' ? '🔗 Top Connected Wallets' : '🪙 Token Holdings'}
            </h3>
            <p className="text-xs text-gray-500 mt-1">
              {activeTab === 'transfers' 
                ? `${connectedWallets.length} wallets found` 
                : `${data.tokens.length} tokens`}
            </p>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'transfers' ? (
              connectedWallets.slice(0, 20).map((wallet, i) => (
                <button
                  key={wallet.address}
                  onClick={() => {
                    setHighlightedNode(wallet.address);
                    setTimeout(() => setHighlightedNode(null), 2500);
                  }}
                  className="w-full px-4 py-3 flex items-center gap-3 hover:bg-white/5 transition-colors text-left border-b border-white/[0.03]"
                >
                  <span className="text-gray-600 text-sm w-7 font-medium">#{i + 1}</span>
                  <div 
                    className="w-4 h-4 rounded-full shrink-0" 
                    style={{ backgroundColor: getColor(wallet.amount) }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-mono text-sm text-white truncate">{formatAddress(wallet.address)}</div>
                    <div className="text-xs text-gray-500 flex items-center gap-2">
                      <span>{formatNumber(wallet.amount)} SOL</span>
                      <span className={`${wallet.isSource ? 'text-red-400' : 'text-green-400'}`}>
                        {wallet.isSource ? '↑ Sent' : '↓ Received'}
                      </span>
                    </div>
                  </div>
                </button>
              ))
            ) : (
              data.tokens.sort((a, b) => b.usdValue - a.usdValue).map((token, i) => (
                <div key={i} className="px-4 py-3 flex items-center gap-3 border-b border-white/[0.03]">
                  <span className="text-2xl">{token.logoUrl || '🪙'}</span>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-white">{token.symbol}</div>
                    <div className="text-xs text-gray-500">{token.name}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-white font-medium">{formatNumber(token.balance)}</div>
                    <div className="text-xs text-gray-500">${formatNumber(token.usdValue)}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Toggle Panel Button */}
        <button
          onClick={() => setShowPanel(!showPanel)}
          className={`
            absolute top-4 z-30 p-2 rounded-lg bg-[#0d0e14] border border-white/10 
            text-gray-400 hover:text-white transition-all duration-300
            ${showPanel ? 'left-[330px]' : 'left-4'}
          `}
        >
          {showPanel ? '◀' : '▶'}
        </button>

        {/* SVG Canvas */}
        <div 
          ref={containerRef}
          className="flex-1 relative overflow-hidden cursor-grab active:cursor-grabbing"
          style={{ marginLeft: showPanel ? '320px' : '0' }}
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
        >
          <svg className="w-full h-full">
            <defs>
              <radialGradient id="mainNodeGradient" cx="30%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#b366ff" />
                <stop offset="100%" stopColor="#9945FF" />
              </radialGradient>
              <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="strongGlow" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="10" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            <g transform={`translate(${pan.x + dimensions.width / 2 * (1 - zoom)}, ${pan.y + dimensions.height / 2 * (1 - zoom)}) scale(${zoom})`}>
              {/* Links */}
              {links.map((link, i) => {
                const source = getNodeById(link.source);
                const target = getNodeById(link.target);
                if (!source || !target) return null;
                
                const ratio = link.amount / maxAmount;
                const strokeWidth = 2 + ratio * 6;
                const color = getColor(link.amount);
                const isHovered = hoveredLink?.source === link.source && hoveredLink?.target === link.target;
                
                // Curved line
                const midX = (source.x + target.x) / 2;
                const midY = (source.y + target.y) / 2;
                const dx = target.x - source.x;
                const dy = target.y - source.y;
                const offset = 30 * (i % 2 === 0 ? 1 : -1);
                const ctrlX = midX - dy * 0.1 + offset;
                const ctrlY = midY + dx * 0.1;
                
                return (
                  <g key={i}>
                    <path
                      d={`M ${source.x} ${source.y} Q ${ctrlX} ${ctrlY} ${target.x} ${target.y}`}
                      stroke={color}
                      strokeWidth={isHovered ? strokeWidth + 3 : strokeWidth}
                      strokeOpacity={isHovered ? 0.9 : 0.5}
                      fill="none"
                      className="transition-all duration-200 cursor-pointer"
                      onMouseEnter={(e) => handleLinkHover(e, link)}
                      onMouseLeave={() => setHoveredLink(null)}
                    />
                    {ratio > 0.4 && (
                      <text
                        x={ctrlX}
                        y={ctrlY - 10}
                        fill={color}
                        fontSize="11"
                        textAnchor="middle"
                        className="font-mono pointer-events-none"
                        style={{ textShadow: '0 0 10px rgba(0,0,0,0.8)' }}
                      >
                        {formatNumber(link.amount)} SOL
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {nodes.map((node) => (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  className={`cursor-pointer ${node.isMain ? '' : 'cursor-grab active:cursor-grabbing'}`}
                  onMouseDown={(e) => handleMouseDown(e, node.id)}
                  onMouseEnter={(e) => handleNodeHover(e, node)}
                  onMouseLeave={handleNodeLeave}
                >
                  {/* Highlight ring */}
                  {highlightedNode === node.id && (
                    <>
                      <circle
                        r={node.radius + 25}
                        fill="none"
                        stroke="#f97316"
                        strokeWidth="4"
                        opacity="0.8"
                        className="animate-ping"
                      />
                      <circle
                        r={node.radius + 15}
                        fill="none"
                        stroke="#f97316"
                        strokeWidth="2"
                        opacity="0.6"
                      />
                    </>
                  )}
                  
                  {/* Outer glow */}
                  <circle
                    r={node.radius + 8}
                    fill={node.isMain ? 'url(#mainNodeGradient)' : node.color}
                    opacity="0.15"
                    filter="url(#glow)"
                  />
                  
                  {/* Main circle */}
                  <circle
                    r={node.radius}
                    fill={node.isMain ? 'url(#mainNodeGradient)' : node.color}
                    stroke={node.isMain ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)'}
                    strokeWidth={node.isMain ? 3 : 2}
                    className="transition-all duration-200 hover:stroke-white"
                    filter={highlightedNode === node.id ? 'url(#strongGlow)' : undefined}
                  />
                  
                  {/* Inner highlight */}
                  <circle
                    r={node.radius * 0.7}
                    fill="none"
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="1"
                  />
                  
                  {/* Labels */}
                  <text
                    y={node.isMain ? -8 : 0}
                    fill="white"
                    fontSize={node.isMain ? 13 : 10}
                    textAnchor="middle"
                    className="font-mono pointer-events-none font-medium"
                    style={{ textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}
                  >
                    {formatAddress(node.id)}
                  </text>
                  {node.isMain && (
                    <text
                      y={10}
                      fill="rgba(255,255,255,0.8)"
                      fontSize="11"
                      textAnchor="middle"
                      className="pointer-events-none"
                    >
                      {formatNumber(node.balance)} SOL
                    </text>
                  )}
                  {!node.isMain && (
                    <text
                      y={node.radius + 16}
                      fill="rgba(255,255,255,0.5)"
                      fontSize="9"
                      textAnchor="middle"
                      className="pointer-events-none font-mono"
                    >
                      {formatNumber(node.amount)} SOL
                    </text>
                  )}
                </g>
              ))}
            </g>
          </svg>

          {/* Node Tooltip */}
          {tooltip && (
            <div
              className={`
                absolute z-40 p-4 rounded-2xl bg-[#12131a]/95 backdrop-blur-xl border-2
                transition-all duration-200 min-w-72 shadow-2xl
                ${tooltip.locked ? 'border-cyan-400 shadow-cyan-500/20' : 'border-[#9945FF]/50'}
              `}
              style={{
                left: Math.min(tooltip.x + 20, dimensions.width - 300),
                top: Math.max(10, Math.min(tooltip.y - 80, dimensions.height - 250)),
              }}
              onMouseEnter={handleTooltipEnter}
              onMouseLeave={handleTooltipLeave}
            >
              {tooltip.locked && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-cyan-500 text-xs text-black font-bold rounded-full shadow-lg">
                  🔒 LOCKED
                </div>
              )}
              
              <div className="flex items-center gap-3 mb-4">
                <div 
                  className="w-5 h-5 rounded-full"
                  style={{ backgroundColor: tooltip.node.isMain ? '#9945FF' : tooltip.node.color }}
                />
                <span className="font-mono text-white font-medium">{formatAddress(tooltip.node.id)}</span>
                {tooltip.node.isMain && (
                  <span className="px-2 py-0.5 bg-[#9945FF]/20 text-[#9945FF] text-xs rounded-full font-medium">
                    MAIN
                  </span>
                )}
              </div>
              
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-gray-500">Balance:</span>
                  <span className="text-white font-medium">{formatNumber(tooltip.node.balance)} SOL</span>
                </div>
                {!tooltip.node.isMain && (
                  <>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-gray-500">Transferred:</span>
                      <span className="text-white font-medium">{formatNumber(tooltip.node.amount)} SOL</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-gray-500">Direction:</span>
                      <span className={tooltip.node.isSource ? 'text-red-400' : 'text-green-400'}>
                        {tooltip.node.isSource ? '↑ Outgoing' : '↓ Incoming'}
                      </span>
                    </div>
                  </>
                )}
              </div>
              
              <div className="flex gap-2">
                <button
                  onClick={() => navigator.clipboard.writeText(tooltip.node.id)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
                >
                  📋 Copy Address
                </button>
                {!tooltip.node.isMain && (
                  <button
                    onClick={() => {
                      setTooltip(null);
                      onWalletClick(tooltip.node.id);
                    }}
                    className="flex-1 py-2.5 px-4 rounded-xl text-white text-sm font-medium transition-all hover:scale-105"
                    style={{ background: 'linear-gradient(135deg, #9945FF, #14F195)' }}
                  >
                    🔍 Track Wallet
                  </button>
                )}
              </div>
              
              <a
                href={`https://solscan.io/account/${tooltip.node.id}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block mt-3 text-center text-xs text-[#14F195] hover:underline"
              >
                View on Solscan ↗
              </a>
            </div>
          )}

          {/* Link Tooltip */}
          {hoveredLink && (
            <div
              className="absolute z-30 px-4 py-2 rounded-xl bg-[#12131a]/95 backdrop-blur-xl border border-white/10 shadow-xl"
              style={{
                left: hoveredLink.x + 10,
                top: hoveredLink.y - 40,
              }}
            >
              <div className="text-white font-medium text-sm">
                {formatNumber(hoveredLink.amount)} SOL
              </div>
              <div className="text-gray-500 text-xs">Transfer amount</div>
            </div>
          )}

          {/* Legend */}
          <div className="absolute bottom-4 left-4 p-4 rounded-xl bg-[#0a0b10]/90 backdrop-blur-xl border border-white/5">
            <div className="text-xs text-gray-500 mb-3 font-medium">Transfer Volume</div>
            <div className="flex items-center gap-5">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-xs text-gray-400">High (&gt;60%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-orange-500" />
                <span className="text-xs text-gray-400">Medium</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-xs text-gray-400">Low</span>
              </div>
            </div>
          </div>

          {/* Zoom Controls */}
          <div className="absolute bottom-4 right-4 flex flex-col gap-2">
            <button
              onClick={() => setZoom(z => Math.min(4, z * 1.3))}
              className="w-12 h-12 rounded-xl bg-[#0a0b10]/90 border border-white/10 text-white hover:bg-white/10 transition-colors text-xl font-medium"
            >
              +
            </button>
            <button
              onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
              className="w-12 h-12 rounded-xl bg-[#0a0b10]/90 border border-white/10 text-white hover:bg-white/10 transition-colors text-sm font-medium"
            >
              Reset
            </button>
            <button
              onClick={() => setZoom(z => Math.max(0.2, z * 0.7))}
              className="w-12 h-12 rounded-xl bg-[#0a0b10]/90 border border-white/10 text-white hover:bg-white/10 transition-colors text-xl font-medium"
            >
              −
            </button>
          </div>
        </div>
      </div>
      
      <style>{`
        @keyframes ping {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50% { transform: scale(1.2); opacity: 0.3; }
        }
        .animate-ping {
          animation: ping 1.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

// Main App
const App: React.FC = () => {
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingStatus, setLoadingStatus] = useState('');

  const handleSearch = useCallback(async (address: string) => {
    setIsLoading(true);
    setLoadingProgress(0);
    setLoadingStatus('Connecting to Solana...');

    const steps = [
      { progress: 15, status: 'Validating address...' },
      { progress: 35, status: 'Fetching wallet data...' },
      { progress: 55, status: 'Analyzing transactions...' },
      { progress: 75, status: 'Building network map...' },
      { progress: 90, status: 'Rendering visualization...' },
    ];

    for (const step of steps) {
      await new Promise(r => setTimeout(r, 250));
      setLoadingProgress(step.progress);
      setLoadingStatus(step.status);
    }

    try {
      const data = await analyzeWallet(address);
      setWalletData(data);
      setLoadingProgress(100);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleBack = useCallback(() => {
    setWalletData(null);
  }, []);

  const handleWalletClick = useCallback((address: string) => {
    handleSearch(address);
  }, [handleSearch]);

  if (isLoading) {
    return <LoadingScreen progress={loadingProgress} status={loadingStatus} />;
  }

  if (walletData) {
    return <BubbleMap data={walletData} onBack={handleBack} onWalletClick={handleWalletClick} />;
  }

  return <LandingPage onSearch={handleSearch} />;
};

// Export with QueryClientProvider
export default function AppWithProviders() {
  return (
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  );
}
