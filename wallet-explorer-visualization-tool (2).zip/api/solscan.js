// API Route sécurisée pour Vercel Serverless Functions
// Votre clé API n'est JAMAIS exposée au client

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Récupérer la clé API depuis les variables d'environnement SERVEUR
  const API_KEY = process.env.SOLSCAN_API_KEY;

  if (!API_KEY) {
    console.error('[API] SOLSCAN_API_KEY not found in environment');
    return res.status(500).json({ 
      success: false,
      error: 'API key not configured',
      message: 'Please add SOLSCAN_API_KEY to your Vercel environment variables'
    });
  }

  const { endpoint, address, tx } = req.query;

  if (!endpoint) {
    return res.status(400).json({ 
      success: false,
      error: 'Missing endpoint parameter' 
    });
  }

  // Construire l'URL Solscan Pro API v2
  let solscanUrl = 'https://pro-api.solscan.io/v2.0';
  
  try {
    switch (endpoint) {
      case 'account':
        if (!address) {
          return res.status(400).json({ success: false, error: 'Missing address' });
        }
        solscanUrl += `/account?address=${address}`;
        break;
        
      case 'account-transfer':
        if (!address) {
          return res.status(400).json({ success: false, error: 'Missing address' });
        }
        solscanUrl += `/account/transfer?address=${address}&page=1&page_size=50&sort_by=block_time&sort_order=desc`;
        break;
        
      case 'account-tokens':
        if (!address) {
          return res.status(400).json({ success: false, error: 'Missing address' });
        }
        solscanUrl += `/account/token-accounts?address=${address}&type=token&page=1&page_size=50`;
        break;
        
      case 'transaction':
        if (!tx) {
          return res.status(400).json({ success: false, error: 'Missing tx signature' });
        }
        solscanUrl += `/transaction/detail?tx=${tx}`;
        break;
        
      default:
        return res.status(400).json({ 
          success: false,
          error: 'Invalid endpoint',
          validEndpoints: ['account', 'account-transfer', 'account-tokens', 'transaction']
        });
    }

    console.log(`[Solscan API] Fetching: ${endpoint} for ${address || tx}`);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    const response = await fetch(solscanUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'token': API_KEY
      },
      signal: controller.signal
    });

    clearTimeout(timeout);

    // Handle rate limiting
    if (response.status === 429) {
      console.warn('[Solscan API] Rate limited');
      return res.status(429).json({ 
        success: false,
        error: 'Rate limited',
        message: 'Too many requests. Please wait a moment and try again.',
        retryAfter: 5
      });
    }

    // Handle other errors
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[Solscan API] Error ${response.status}: ${errorText}`);
      return res.status(response.status).json({ 
        success: false,
        error: 'Solscan API error',
        status: response.status,
        message: errorText
      });
    }

    const data = await response.json();
    
    // Cache for 10 seconds, revalidate in background for 30 seconds
    res.setHeader('Cache-Control', 's-maxage=10, stale-while-revalidate=30');
    
    return res.status(200).json({
      success: true,
      data: data.data || data,
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('[Solscan API] Error:', error.message);
    
    if (error.name === 'AbortError') {
      return res.status(504).json({ 
        success: false,
        error: 'Request timeout',
        message: 'The request took too long. Please try again.'
      });
    }
    
    return res.status(500).json({ 
      success: false,
      error: 'Server error',
      message: error.message 
    });
  }
}
