# 🔍 Solana Explorer

Professional Solana Wallet Tracker avec Bubble Maps interactives.

---

## 🚀 DÉPLOIEMENT SUR VERCEL (5 minutes)

### Étape 1 : Téléchargez ce projet

Téléchargez le ZIP depuis Arena et extrayez-le sur votre ordinateur.

### Étape 2 : Préparez les fichiers

**⚠️ IMPORTANT : Supprimez ces fichiers/dossiers s'ils existent :**
- `.env.local` (contient votre clé !)
- `node_modules/`
- `dist/`

### Étape 3 : Uploadez sur GitHub

1. Allez sur https://github.com → **New repository**
2. Nom : `solana-explorer`
3. Choisissez **Private**
4. **NE PAS** cocher "Add README/gitignore/license"
5. Cliquez **Create repository**
6. Cliquez **"uploading an existing file"**
7. Glissez-déposez TOUS vos fichiers
8. Cliquez **Commit changes**

### Étape 4 : Déployez sur Vercel

1. Allez sur https://vercel.com
2. **Sign Up** → **Continue with GitHub**
3. Cliquez **Add New... → Project**
4. Sélectionnez `solana-explorer`
5. Cliquez **Import**

### Étape 5 : Ajoutez votre clé API (CRITIQUE !)

1. Dans la section **Environment Variables** :
   - **Name** : `SOLSCAN_API_KEY`
   - **Value** : `votre-clé-api-solscan`
2. Cliquez **Add**

### Étape 6 : Déployez !

1. Vérifiez les paramètres :
   - Framework Preset : **Vite**
   - Output Directory : **dist**
2. Cliquez **Deploy**
3. Attendez 2-3 minutes

### ✅ Votre site est en ligne !

URL : `https://solana-explorer-xxxxx.vercel.app`

---

## 🔐 Sécurité de votre clé API

**Votre clé est 100% sécurisée :**

```
[Visiteur] → [Votre serveur Vercel] → [Solscan API]
                    ↑
             La clé est ICI
         (invisible pour les visiteurs)
```

- ❌ La clé n'est JAMAIS dans le code JavaScript du navigateur
- ❌ Les visiteurs NE PEUVENT PAS voir votre clé
- ✅ La clé reste chiffrée sur les serveurs Vercel

---

## 🔍 Référencement Google

Après déploiement :

1. Allez sur https://search.google.com/search-console
2. Ajoutez votre URL Vercel
3. Soumettez le sitemap : `sitemap.xml`
4. Demandez l'indexation

**Délai : 3-7 jours** pour apparaître sur Google.

---

## 🆘 Problèmes courants

### Erreur 404
→ Vérifiez que `vercel.json` est bien uploadé sur GitHub

### API ne fonctionne pas
→ Vérifiez que `SOLSCAN_API_KEY` est ajoutée dans Vercel → Settings → Environment Variables

### Build failed
→ Vérifiez que tous les fichiers sont uploadés sur GitHub

---

## 📞 Support

Si vous êtes bloqué, dites-moi :
1. À quelle étape vous êtes
2. Le message d'erreur
3. Une capture d'écran si possible
